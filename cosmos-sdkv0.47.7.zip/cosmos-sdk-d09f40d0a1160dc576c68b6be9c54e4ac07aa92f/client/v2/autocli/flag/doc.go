// Package flag defines functionality for automatically managing command
// line flags as well positional arguments that are based on protobuf message
// fields.
package flag
