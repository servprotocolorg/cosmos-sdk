---
name: Epic
about: Create an epic/user

---

<!-- < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < ☺ 
v                            ✰  Thanks for opening an issue! ✰    
v    Before smashing the submit button please review the template.
v    Word of caution: poorly thought-out proposals may be rejected 
v                     without deliberation 
☺ > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > >  -->

## Summary

<!-- Short, concise description of the proposed feature/changes to the repository
What are the user needs?
How could this solution fix the user facing problem?  -->

## Problem Definition

<!-- Why do we need this feature? 
What problems may be addressed by introducing this feature?
What benefits does the SDK stand to gain by including this feature?
Are there any disadvantages of including this feature? -->

## Work Breakdown

<!-- Break the work into many bullet points that will later be turned into issues that can be assigned to developers to work on 
This work may been to be broken up into phases of work in order to better organize when and how things get done. -->
